///////Smovzhenko Anton


#include "Trapezoid.h"

#include <iostream>

#include <cassert>

#include <cmath>

#define TOLERANCE 0.0000001
using namespace std;

int main()
{
	cout << "Test construtors" << endl;

	//constructors
	Trapezoid t1(0, 0, 0, 1, 2, 1, 4, 0);
	Trapezoid t2(t1);

	cout << "Test equality" << endl;

	double t2Area = t2.area();
	assert(t1 == t2);

	cout << "Test getters" << endl;

	assert(t1.getC() == t2.getC());
	assert(t1.getAD().Start() == t1.getA());

	cout << "Test area and perimeter" << endl;

	double t1Area = 3;
	double t1Perimeter = 7 + sqrt(5);
	assert(fabs(t1.area() - t1Area) < TOLERANCE);
	assert(fabs(t1.perimeter() - t1Perimeter) < TOLERANCE);


	cout << "Test setters" << endl;

	Point C(3, 1);
	t1.setC(C);
	assert(C == t1.getBC().End());
	assert(t1 != t2);

	cout << "Test invalid trapezoid" << endl;
	Point badC(4, 4);
	try {
		t1.setC(badC);
	}
	catch (Trapezoid::BadTrapezoid& error) {
		cout << " ERROR " << error.getReason() << endl;
	}
	try {
		Trapezoid bad(1, 1, 2, 2, 11, 6, 1.5, 1);
	}
	catch (Trapezoid::BadTrapezoid& error) {
		cout << " ERROR " << error.getReason() << endl;
	}

}

