#pragma once

#include "DequeList.h"
#include "Peek.h"
#include <iostream>
using namespace std;

template<class T>
class ListPeekDeque : public DequeList<T>, public Peek<T>
{
public:

	ListPeekDeque() : DequeList<T>()
	{
		cout << "Peekback list deque was created" << endl;
	}

	~ListPeekDeque()
	{
		cout << "Peekback list deque was deleted" << endl;
	}

	const T& peek(size_t index) const
	{
		if (index >= DequeList<T>::_size)
		{
			throw Deque<T>::BadDeque("| Incorrect index |");
		}
		typename DequeList<T>::Node* current = DequeList<T>::_head;
		for (size_t i = 0; i < index; ++i)
		{
			current = current->_next;
		}
		return current->_value;
	}

};
