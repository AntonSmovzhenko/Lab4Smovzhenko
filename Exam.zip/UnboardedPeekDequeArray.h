#pragma once

#include "DequeUnboundedArray.h"
#include "Peek.h"
#include <iostream>

using namespace std;

template<class T>
class UnboundedPeekDequeArray : public DequeUnboundedArray<T>, public Peek<T>
{
public:

	UnboundedPeekDequeArray() : DequeUnboundedArray<T>()
	{
		cout << "Peekback unbounded array deque was created" << endl;
	}

	~UnboundedPeekDequeArray()
	{
		cout << "Peekback unbounded array deque was deleted" << endl;
	}

	const T& peek(size_t index) const
	{
		if (index >= BoundedDequeArray<T>::_size)
		{
			throw Deque<T>::BadDeque("| Incorrect index |");
		}
		return BoundedDequeArray<T>::_array->operator[]((BoundedDequeArray<T>::_front + index)
			% BoundedDequeArray<T>::_array->length());
	}

};
