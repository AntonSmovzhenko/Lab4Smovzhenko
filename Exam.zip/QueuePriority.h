#pragma once

#include "DequeList.h"
#include <iostream>
using namespace std;

template<class T>
class QueuePriority
{
private:

	struct Node
	{

		T _value;
		Node* _prev, * _next;

		Node(const T& value, Node* prev, Node* next) :
			_value(value), _prev(prev), _next(next) {}

	};

	Node* _head, * _tail;
	size_t _size;

	void createFirstNode(const T& value)
	{
		_head = new Node(value, 0, 0);
		_tail = _head;
		return;
	}

	Node* popNode()
	{
		Node* nodeToDelete = new Node(0, 0, 0);
		Node* current = _head;
		while (current != nullptr)
		{
			if (current->_value > nodeToDelete->_value)
			{
				nodeToDelete = current;
			}
			current = current->_next;
		}
		return nodeToDelete;
	}

public:

	class Iterator
	{
	private:

		Node* _current;

	public:

		Iterator() : _current(0) {}

		Iterator(Node* node) : _current(node) {}

		bool stop() const
		{
			return _current == 0;
		}

		Iterator operator++()
		{
			_current = _current->_next;
			return *this;
		}

		const T& operator*() const
		{
			return _current->_value;
		}

		T& operator*()
		{
			return _current->_value;
		}

	};

	class BadQueue
	{
	private:

		string _reason;

	public:

		BadQueue(string reason = "") :_reason(reason) {};

		~BadQueue() {};

		void diagnose() const
		{
			cerr << _reason << endl;
		}
	};

	QueuePriority() : _size(0), _head(0), _tail(0)
	{
		cout << "QueuePriority was created" << endl;
	}

	~QueuePriority()
	{
		Node* next = _head;
		Node* cur;
		while (next != nullptr)
		{
			cur = next;
			next = next->_next;
			delete cur;
		}
		cout << "QueuePriority was deleted" << endl;
	}

	Iterator attach()
	{
		return Iterator(_head);
	}

	bool empty() const
	{
		return _size == 0;
	}

	bool full() const
	{
		return false;
	}

	const T& front() const
	{
		if (empty())
		{
			throw BadQueue("| There are no elements in the priority queue |");
		}
		return _head->_value;
	}

	const T& back() const
	{
		if (empty())
		{
			throw BadQueue("| There are no elements in the priority queue |");
		}
		return _tail->_value;
	}

	void pop()
	{
		if (empty())
		{
			throw BadQueue("| There is nothing to delete in the list deque |");
		}
		Node* nodeToDelete = popNode();
		Node* current = _head;
		while (current != nullptr)
		{
			if (current == nodeToDelete)
			{
				if (current == _head)
				{
					_head->_next->_prev = 0;
					_head = _head->_next;
				}
				else if (current == _tail)
				{
					_tail->_prev->_next = 0;
					_tail = _tail->_prev;
				}
				else
				{
					current->_prev->_next = current->_next;
					current->_next->_prev = current->_prev;
				}
				break;
			}
			current = current->_next;
		}
		_size--;
	}

	void put(const T& value)
	{
		if (empty())
		{
			createFirstNode(value);
		}
		else
		{
			_tail->_next = new Node(value, _tail, 0);
			_tail = _tail->_next;
		}
		_size++;
	}

	size_t capacity() const
	{
		return _size;
	}

	size_t size() const
	{
		return _size;
	}

};

template<class T>
ostream& operator<<(ostream& ostr, typename QueuePriority<T>::Iterator& itor)
{
	ostr << '{';
	while (!itor.stop())
	{
		ostr << *itor;
		++itor;
		if (!itor.stop())
		{
			ostr << ", ";
		}
	}
	ostr << '}';
	return ostr;
}

