#pragma once

#include "BoundedDequeArray.h"
#include "Peek.h"
#include <iostream>
using namespace std;

template<class T>
class BoundedPeekDequeArray : public BoundedDequeArray<T>, public Peek<T>
{
public:

	BoundedPeekDequeArray(const size_t& capacity) : BoundedDequeArray<T>(capacity)
	{
		cout << "Peekback bounded array deque was created" << endl;
	}

	~BoundedPeekDequeArray()
	{
		cout << "Peekback bounded array deque was deleted" << endl;
	}

	const T& peek(size_t index) const
	{
		if (index >= BoundedDequeArray<T>::_size)
		{
			throw Deque<T>::BadDeque("| Incorrect index |");
		}
		return BoundedDequeArray<T>::_array->operator[]((BoundedDequeArray<T>::_front + index)
			% BoundedDequeArray<T>::_array->length());
	}

};
