#pragma once

#include "Deque.h"
#include "Array.h"
#include <iostream>
using namespace std;

template<class T>
class BoundedDequeArray : public Deque<T>
{
protected:
	Array<T>* _array;
	size_t _size, _front, _back;

public:

	class Iterator;

	BoundedDequeArray(const size_t& capacity) :
		_size(0), _front(capacity / 2), _back(_front), _array(new Array<T>(capacity))
	{
		cout << "The bounded array deque with size " << capacity << " was created" << endl;
	}

	~BoundedDequeArray()
	{
		delete _array;
		cout << "The bounded array deque was deleted" << endl;
	}

	Iterator attach()
	{
		return Iterator(_array, _size, _front, _back);
	}

	bool empty() const
	{
		return _size == 0;
	}

	bool full() const
	{
		return _size == _array->length();
	}

	const T& front() const
	{
		if (empty())
		{
			throw Deque<T>::BadDeque("| There are no elements in the bounded array deque |");
		}
		return *(_array+_front);
	}

	const T& back() const
	{
		if (empty())
		{
			throw Deque<T>::BadDeque("| There are no elements in the bounded array deque |");
		}
		return *(_array+_back);
	}

	void popFront()
	{
		if (empty())
		{
			throw Deque<T>::BadDeque("| There are no elements in the bounded array deque |");
		}
		_size--;
		_front = (_front < _array->length() - 1) ? (_front + 1) : 0;
		return;
	}

	void popBack()
	{
		if (empty())
		{
			throw Deque<T>::BadDeque("| There are no elements in the bounded array deque |");
		}
		_size--;
		_back = (_back > 0) ? (_back - 1) : (_array->length() - 1);
	}

	void putFront(const T& value)
	{
		if (full())
		{
			throw Deque<T>::BadDeque("| There is no free space to add new element |");
		}
		if (!empty())
		{
			_front = (_front > 0) ? (_front - 1) : (_array->length() - 1);
		}
		*(_array+_front) = value;
		_size++;
	}

	void putBack(const T& value)
	{
		if (full())
		{
			throw Deque<T>::BadDeque("| There is no free space to add new element |");
		}
		if (!empty())
		{
			_back = (_back < _array->length() - 1) ? (_back + 1) : 0;
		}
		*(_array+_back) = value;
		_size++;
	}

	size_t capacity() const
	{
		return _array->length();
	}

	size_t size() const
	{
		return _size;
	}

};

template<class T>
class BoundedDequeArray<T>::Iterator
{
private:

	Array<T>* _array;
	size_t _size, _current, _end;
	mutable bool _isFinish = false;

public:

	Iterator() : _array(0), _current(0), _end(0) {}

	Iterator(Array<T>* array, size_t& size, size_t& front, size_t& back) :
		_array(array), _size(size), _current(front), _end(back) {}

	bool stop() const
	{
		if (_size != 1 && _size != 0)
		{
			if (_isFinish && _current != _end)
			{
				return _isFinish;
			}
			else if (_current == _end)
			{
				_isFinish = true;
				return !_isFinish;
			}
		}
		else if (_size == 0)
		{
			return !_isFinish;
		}
		else if (_size == 1 && !_isFinish)
		{
			_isFinish = true;
			return !_isFinish;
		}
		return _isFinish;
	}

	Iterator operator++()
	{
		_current = (_current < _array->length() - 1) ? _current + 1 : 0;
		return *this;
	}

	const T& operator*() const
	{
		return *(_array+_current);
	}

	T& operator*()
	{
		return *(_array+_current);
	}

};

template<class T>
ostream& operator<<(ostream& os, typename BoundedDequeArray<T>::Iterator& itor)
{
	os << '{';
	while (!itor.stop()) {
		os << *itor;
		++itor;
		if (!itor.stop())
		{
			os << ", ";
		}
	}
	os << '}';
	return os;
}
