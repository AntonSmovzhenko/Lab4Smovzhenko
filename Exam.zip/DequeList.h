#pragma once

#include "Deque.h"
#include <iostream>
using namespace std;

template<class T>
class DequeList : public Deque<T>
{
protected:

	struct Node
	{

		T _value;
		Node* _prev, * _next;

		Node(const T& value, Node* prev, Node* next) :
			_value(value), _prev(prev), _next(next) {}

	};
	Node* _head, * _tail;
	size_t _size;

	void createFirstNode(const T& value)
	{
		_head = new Node(value, 0, 0);
		_tail = _head;
	}

public:

	class Iterator;

	DequeList() : _size(0), _head(0), _tail(0)
	{
		cout << "DequeList was created" << endl;
	}

	~DequeList()
	{
		Node* next = _head;
		Node* cur;
		while (next != nullptr)
		{
			cur = next;
			next = next->_next;
			delete cur;
		}
		cout << "DequeList was deleted" << endl;
	}

	Iterator attach()
	{
		return Iterator(_head);
	}

	bool empty() const
	{
		return _size == 0;
	}

	bool full() const
	{
		return false;
	}

	const T& front() const
	{
		if (empty())
		{
			throw Deque<T>::BadDeque("| There are no elements in the list deque |");
		}
		return _head->_value;
	}

	const T& back() const
	{
		if (empty())
		{
			throw Deque<T>::BadDeque("| There are no elements in the list deque |");
		}
		return _tail->_value;
	}

	void popFront()
	{
		if (empty())
		{
			throw Deque<T>::BadDeque("| There is nothing to delete in the list deque |");
		}
		Node* newHead = _head->_next;
		delete _head;
		_head = newHead;
		_tail->_prev = 0;
		_size--;
	}

	void popBack()
	{
		if (empty())
		{
			throw Deque<T>::BadDeque("| There is nothing to delete in the list deque |");
		}
		Node* newTail = _tail->_prev;
		delete _tail;
		_tail = newTail;
		_tail->_next = 0;
		_size--;
	}

	void putFront(const T& value)
	{
		if (empty())
		{
			createFirstNode(value);
		}
		else
		{
			_head->_prev = new Node(value, 0, _head);
			_head = _head->_prev;

		}
		_size++;
	}

	void putBack(const T& value)
	{
		if (empty())
		{
			createFirstNode(value);
		}
		else
		{
			_tail->_next = new Node(value, _tail, 0);
			_tail = _tail->_next;
		}
		_size++;
	}

	size_t capacity() const
	{
		return _size;
	}

	size_t size() const
	{
		return _size;
	}

};

template<class T>
class DequeList<T>::Iterator
{
private:

	typename DequeList<T>::Node* _current;

public:

	Iterator() : _current(0) {}

	Iterator(typename DequeList<T>::Node* node) : _current(node) {}

	bool stop() const
	{
		return _current == 0;
	}

	Iterator operator++()
	{
		_current = _current->_next;
		return *this;
	}

	const T& operator*() const
	{
		return _current->_value;
	}

	T& operator*()
	{
		return _current->_value;
	}

};

template<class T>
ostream& operator<<(ostream& ostr, typename DequeList<T>::Iterator& itor)
{
	ostr << '{';
	while (!itor.stop())
	{
		ostr << *itor;
		++itor;
		if (!itor.stop())
		{
			ostr << ", ";
		}
	}
	ostr << '}';
	return ostr;
}
