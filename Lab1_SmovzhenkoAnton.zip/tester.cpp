#include "Point.h"
#include <iostream>

//Smovzhenko Anton

using namespace std;

int main() {
    Point x(1,1);
    Point y(2,2);
    Point z(3,3);
}
